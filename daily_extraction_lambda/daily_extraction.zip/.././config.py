
class Configs():
    def __init__(self):
        self.BUCKET = "test-bucket-1-jswest8314"  # the name of the S3 bucket to which the data will be written
        self.csu_stations = ["ftc02", "ftc04", "lov01", "fcl01",
                                "jcn01"]  # https://coagmet.colostate.edu/station/selector
        self.cocorahs_stations = ["CO-LR-290", "CO-LR-1304", "CO-LR-1331",
                                     "CO-LR-1336"]  # https://maps.cocorahs.org/
        self.gov_stations = ["KFNL"]  # https://www.weather.gov/
